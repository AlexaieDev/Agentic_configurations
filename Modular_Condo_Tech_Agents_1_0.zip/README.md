# Modular Condo Tech Agents 1.0

Pack de agentes técnicos para construir un sistema de administración de condominios
con arquitectura modular, Web + Mobile, pagos y despliegue cloud.

## Qué incluye
- Arquitectura y contratos
- Diseño UX/UI + Design System + Accesibilidad
- Desarrollo Web/Mobile/Backend
- Arquitectura de datos
- CI/CD + GitOps
- Seguridad y quality gates
- Observabilidad y SRE (para escalamiento)
- Documentación táctica y de gobernanza

## Uso rápido
1) Define módulos y límites con Architecture Orchestrator.
2) Congela interfaces con Interface & Contracts antes de construir UI.
3) Diseña flujos con UX/UI y consolida componentes con Design System.
4) Implementa Backend + Web (y Mobile si aplica).
5) Activa Test Strategy y gates en CI/CD.
6) Refuerza seguridad de pagos con Threat Modeling + Security Testing Integrator.
7) Antes de producción, habilita Observability y Runbooks.

Revisa `index.txt` para kits sugeridos.
